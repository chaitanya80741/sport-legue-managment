package com.leaguehub.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.leaguehub.model.Team;

public interface TeamRepository extends JpaRepository<Team, Long> {}
