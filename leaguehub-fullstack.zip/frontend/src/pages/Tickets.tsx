
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Calendar, Clock, MapPin, Ticket } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import Navbar from '@/components/Navbar';

type Seat = {
  id: string;
  section: string;
  row: string;
  number: number;
  price: number;
  available: boolean;
};

type BookedTicket = {
  id: string;
  matchId: string;
  homeTeam: string;
  awayTeam: string;
  date: string;
  time: string;
  venue: string;
  seat: Seat;
  confirmationCode: string;
};

const generateRandomSeats = (count: number): Seat[] => {
  const sections = ['A', 'B', 'C'];
  const rows = ['1', '2', '3', '4', '5'];
  
  return Array(count).fill(null).map(() => ({
    id: Math.random().toString(36).substr(2, 9),
    section: sections[Math.floor(Math.random() * sections.length)],
    row: rows[Math.floor(Math.random() * rows.length)],
    number: Math.floor(Math.random() * 20) + 1,
    price: Math.floor(Math.random() * 50) + 50,
    available: Math.random() > 0.3
  }));
};

const generateRandomMatch = () => {
  const teams = [
    'Red Dragons', 'Blue Knights', 'Golden Eagles', 'Silver Wolves',
    'Green Lions', 'Purple Panthers', 'Black Bears', 'White Tigers'
  ];
  
  const venues = [
    'Central Stadium', 'East Arena', 'West Park', 'North Field',
    'South Complex', 'Downtown Arena', 'City Stadium', 'Metro Ground'
  ];

  const futureDate = new Date();
  futureDate.setDate(futureDate.getDate() + Math.floor(Math.random() * 30));

  const allTeams = [...teams];
  const homeTeamIndex = Math.floor(Math.random() * allTeams.length);
  const homeTeam = allTeams.splice(homeTeamIndex, 1)[0];
  const awayTeam = allTeams[Math.floor(Math.random() * allTeams.length)];

  return {
    id: Math.random().toString(36).substr(2, 9),
    date: futureDate.toISOString().split('T')[0],
    time: `${String(Math.floor(Math.random() * 12) + 8).padStart(2, '0')}:${String(Math.floor(Math.random() * 4) * 15).padStart(2, '0')}`,
    homeTeam,
    awayTeam,
    venue: venues[Math.floor(Math.random() * venues.length)]
  };
};

const Tickets = () => {
  const [selectedMatch, setSelectedMatch] = useState<ReturnType<typeof generateRandomMatch> | null>(null);
  const [availableSeats, setAvailableSeats] = useState<Seat[]>([]);
  const [bookedTickets, setBookedTickets] = useState<BookedTicket[]>([]);
  const [showBooking, setShowBooking] = useState(false);
  const { toast } = useToast();

  const handleSelectMatch = () => {
    const match = generateRandomMatch();
    setSelectedMatch(match);
    setAvailableSeats(generateRandomSeats(15));
    setShowBooking(true);
  };

  const handleBookTicket = (seat: Seat) => {
    if (!selectedMatch) return;

    const confirmationCode = Math.random().toString(36).substr(2, 8).toUpperCase();
    const newTicket: BookedTicket = {
      id: Math.random().toString(36).substr(2, 9),
      matchId: selectedMatch.id,
      homeTeam: selectedMatch.homeTeam,
      awayTeam: selectedMatch.awayTeam,
      date: selectedMatch.date,
      time: selectedMatch.time,
      venue: selectedMatch.venue,
      seat,
      confirmationCode
    };

    setBookedTickets(prev => [newTicket, ...prev]);
    setShowBooking(false);
    setSelectedMatch(null);

    toast({
      title: "Ticket Booked Successfully!",
      description: `Confirmation Code: ${confirmationCode}`,
      duration: 5000,
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="container mx-auto px-4 pt-20">
        <div className="space-y-8">
          <div className="flex justify-between items-center">
            <h1 className="text-2xl font-bold">Match Tickets</h1>
            <Button onClick={handleSelectMatch} className="animate-fade-in">
              <Ticket className="mr-2 h-4 w-4" />
              Book New Ticket
            </Button>
          </div>

          {showBooking && selectedMatch && (
            <Card className="animate-fade-in">
              <CardHeader>
                <CardTitle>{selectedMatch.homeTeam} vs {selectedMatch.awayTeam}</CardTitle>
                <CardDescription className="flex items-center gap-4">
                  <span className="flex items-center gap-1">
                    <Calendar className="h-4 w-4" />
                    {selectedMatch.date}
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock className="h-4 w-4" />
                    {selectedMatch.time}
                  </span>
                  <span className="flex items-center gap-1">
                    <MapPin className="h-4 w-4" />
                    {selectedMatch.venue}
                  </span>
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {availableSeats.map((seat) => (
                    <Card key={seat.id} className={`cursor-pointer transition-all ${seat.available ? 'hover:shadow-lg' : 'opacity-50'}`}>
                      <CardContent className="p-4">
                        <div className="flex justify-between items-center">
                          <div>
                            <p className="font-medium">Section {seat.section}</p>
                            <p className="text-sm text-muted-foreground">Row {seat.row}, Seat {seat.number}</p>
                          </div>
                          <p className="text-lg font-bold">${seat.price}</p>
                        </div>
                      </CardContent>
                      <CardFooter>
                        <Button 
                          className="w-full" 
                          disabled={!seat.available}
                          onClick={() => handleBookTicket(seat)}
                        >
                          {seat.available ? 'Book Seat' : 'Unavailable'}
                        </Button>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {bookedTickets.length > 0 && (
            <div className="space-y-4">
              <h2 className="text-xl font-semibold">Your Tickets</h2>
              <div className="rounded-lg border bg-card">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Match</TableHead>
                      <TableHead>Date & Time</TableHead>
                      <TableHead>Seat</TableHead>
                      <TableHead>Confirmation</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {bookedTickets.map((ticket) => (
                      <TableRow key={ticket.id} className="cursor-pointer hover:bg-muted/50">
                        <TableCell>{ticket.homeTeam} vs {ticket.awayTeam}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Calendar className="h-4 w-4" />
                            {ticket.date}
                            <Clock className="h-4 w-4 ml-2" />
                            {ticket.time}
                          </div>
                        </TableCell>
                        <TableCell>
                          Section {ticket.seat.section}, Row {ticket.seat.row}, Seat {ticket.seat.number}
                        </TableCell>
                        <TableCell className="font-mono">{ticket.confirmationCode}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

export default Tickets;

