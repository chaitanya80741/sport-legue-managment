
import { FC } from "react";
import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Trophy, Calendar, Clock, MapPin, Users, Ticket } from "lucide-react";
import Navbar from "@/components/Navbar";
import { cn } from "@/lib/utils";

interface Match {
  id: string;
  homeTeam: string;
  awayTeam: string;
  date: string;
  time: string;
  venue: string;
  status: "Upcoming" | "Live" | "Completed";
  homeScore?: number;
  awayScore?: number;
  winProbability?: {
    home: number;
    away: number;
  };
}

const Dashboard: FC = () => {
  const [matches, setMatches] = useState<Match[]>([
    {
      id: "1",
      homeTeam: "Red Dragons",
      awayTeam: "Blue Knights",
      date: "2024-03-15",
      time: "19:30",
      venue: "Central Stadium",
      status: "Upcoming",
      winProbability: {
        home: 60,
        away: 40,
      },
    },
    {
      id: "2",
      homeTeam: "Green Eagles",
      awayTeam: "Yellow Lions",
      date: "2024-03-14",
      time: "20:00",
      venue: "East Arena",
      status: "Live",
      homeScore: 2,
      awayScore: 1,
      winProbability: {
        home: 55,
        away: 45,
      },
    },
    {
      id: "3",
      homeTeam: "Purple Warriors",
      awayTeam: "Orange Tigers",
      date: "2024-03-13",
      time: "18:45",
      venue: "West Ground",
      status: "Completed",
      homeScore: 3,
      awayScore: 2,
    },
  ]);

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="container mx-auto px-4 pt-20">
        <h1 className="text-4xl font-bold mb-8 animate-fadeIn">Dashboard</h1>
        
        {/* Live Matches */}
        <section className="mb-8 animate-slideIn">
          <h2 className="text-2xl font-semibold mb-4">Live Matches</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {matches
              .filter((match) => match.status === "Live")
              .map((match) => (
                <Card key={match.id} className="hover:shadow-lg transition-shadow duration-300">
                  <CardHeader className="bg-primary/10 rounded-t-lg">
                    <CardTitle className="flex items-center justify-between">
                      <span className="text-primary">LIVE</span>
                      <span className="text-sm font-normal">{match.time}</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="pt-4">
                    <div className="flex justify-between items-center mb-4">
                      <div className="text-lg font-semibold">{match.homeTeam}</div>
                      <div className="text-2xl font-bold">{match.homeScore} - {match.awayScore}</div>
                      <div className="text-lg font-semibold">{match.awayTeam}</div>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
                      <MapPin className="h-4 w-4" />
                      {match.venue}
                    </div>
                    <div className="flex justify-between items-center mt-4">
                      <Button variant="outline" className="w-[48%]">
                        View Details
                      </Button>
                      <Button className="w-[48%]">
                        <Ticket className="mr-2 h-4 w-4" />
                        Book Tickets
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
          </div>
        </section>

        {/* Upcoming Matches */}
        <section className="mb-8 animate-slideIn">
          <h2 className="text-2xl font-semibold mb-4">Upcoming Matches</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {matches
              .filter((match) => match.status === "Upcoming")
              .map((match) => (
                <Card key={match.id} className="hover:shadow-lg transition-shadow duration-300">
                  <CardContent className="pt-6">
                    <div className="flex justify-between items-center mb-4">
                      <div className="text-lg font-semibold">{match.homeTeam}</div>
                      <div className="text-lg font-semibold">VS</div>
                      <div className="text-lg font-semibold">{match.awayTeam}</div>
                    </div>
                    <div className="flex flex-col gap-2 text-sm text-muted-foreground mb-4">
                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4" />
                        {new Date(match.date).toLocaleDateString()}
                      </div>
                      <div className="flex items-center gap-2">
                        <Clock className="h-4 w-4" />
                        {match.time}
                      </div>
                      <div className="flex items-center gap-2">
                        <MapPin className="h-4 w-4" />
                        {match.venue}
                      </div>
                    </div>
                    {match.winProbability && (
                      <div className="mb-4">
                        <div className="text-sm font-medium mb-2">Win Probability</div>
                        <div className="flex justify-between text-sm">
                          <span>{match.winProbability.home}%</span>
                          <span>{match.winProbability.away}%</span>
                        </div>
                        <div className="w-full h-2 bg-secondary rounded-full mt-1">
                          <div
                            className="h-full bg-primary rounded-full transition-all duration-300"
                            style={{ width: `${match.winProbability.home}%` }}
                          />
                        </div>
                      </div>
                    )}
                    <div className="flex justify-between items-center">
                      <Button variant="outline" className="w-[48%]">
                        View Details
                      </Button>
                      <Button className="w-[48%]">
                        <Ticket className="mr-2 h-4 w-4" />
                        Book Tickets
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
          </div>
        </section>

        {/* Recent Results */}
        <section className="mb-8 animate-slideIn">
          <h2 className="text-2xl font-semibold mb-4">Recent Results</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {matches
              .filter((match) => match.status === "Completed")
              .map((match) => (
                <Card key={match.id} className="hover:shadow-lg transition-shadow duration-300">
                  <CardContent className="pt-6">
                    <div className="flex justify-between items-center mb-4">
                      <div className="text-lg font-semibold">{match.homeTeam}</div>
                      <div className="text-2xl font-bold">{match.homeScore} - {match.awayScore}</div>
                      <div className="text-lg font-semibold">{match.awayTeam}</div>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground mb-4">
                      <Trophy className="h-4 w-4 text-primary" />
                      <span className="font-medium">
                        {match.homeScore! > match.awayScore!
                          ? match.homeTeam
                          : match.awayScore! > match.homeScore!
                          ? match.awayTeam
                          : "Draw"}
                      </span>
                    </div>
                    <Button variant="outline" className="w-full">
                      Match Summary
                    </Button>
                  </CardContent>
                </Card>
              ))}
          </div>
        </section>
      </div>
    </div>
  );
};

export default Dashboard;
