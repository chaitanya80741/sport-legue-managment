import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Calendar, Clock, MapPin, Search, Plus, Edit, Trash } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import Navbar from '@/components/Navbar';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';

type MatchStatus = 'Upcoming' | 'Ongoing' | 'Completed';
type MatchType = 'League' | 'Knockout' | 'Friendly';

type Match = {
  id: string;
  date: string;
  time: string;
  homeTeam: string;
  awayTeam: string;
  venue: string;
  status: MatchStatus;
  type: MatchType;
  homeScore?: number;
  awayScore?: number;
};

const teams = [
  'Red Dragons', 'Blue Knights', 'Golden Eagles', 'Silver Wolves',
  'Green Lions', 'Purple Panthers', 'Black Bears', 'White Tigers'
];

const venues = [
  'Central Stadium', 'East Arena', 'West Park', 'North Field',
  'South Complex', 'Downtown Arena', 'City Stadium', 'Metro Ground'
];

const generateRandomMatch = (): Match => {
  const allTeams = [...teams];
  const homeTeamIndex = Math.floor(Math.random() * allTeams.length);
  const homeTeam = allTeams.splice(homeTeamIndex, 1)[0];
  const awayTeam = allTeams[Math.floor(Math.random() * allTeams.length)];
  
  const statuses: MatchStatus[] = ['Upcoming', 'Ongoing', 'Completed'];
  const types: MatchType[] = ['League', 'Knockout', 'Friendly'];
  const status = statuses[Math.floor(Math.random() * statuses.length)];
  
  // Generate a random date within next 30 days
  const futureDate = new Date();
  futureDate.setDate(futureDate.getDate() + Math.floor(Math.random() * 30));
  
  const match: Match = {
    id: Math.random().toString(36).substr(2, 9),
    date: futureDate.toISOString().split('T')[0],
    time: `${String(Math.floor(Math.random() * 12) + 8).padStart(2, '0')}:${String(Math.floor(Math.random() * 4) * 15).padStart(2, '0')}`,
    homeTeam,
    awayTeam,
    venue: venues[Math.floor(Math.random() * venues.length)],
    status,
    type: types[Math.floor(Math.random() * types.length)]
  };

  if (status === 'Ongoing' || status === 'Completed') {
    match.homeScore = Math.floor(Math.random() * 5);
    match.awayScore = Math.floor(Math.random() * 5);
  }

  return match;
};

const generateInitialMatches = (count: number): Match[] => {
  return Array(count).fill(null).map(() => generateRandomMatch());
};

const Schedule = () => {
  const [matches, setMatches] = useState<Match[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedMatch, setSelectedMatch] = useState<Match | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    setMatches(generateInitialMatches(5));
  }, []);

  const handleCreateMatch = () => {
    const newMatch = generateRandomMatch();
    setMatches(prev => [newMatch, ...prev]);
    toast({
      title: "Match Created",
      description: `New match: ${newMatch.homeTeam} vs ${newMatch.awayTeam}`,
      duration: 3000,
    });
  };

  const handleMatchClick = (match: Match) => {
    setSelectedMatch(match);
    toast({
      title: "Match Details",
      description: `${match.homeTeam} vs ${match.awayTeam} - ${match.venue}`,
      duration: 3000,
    });
  };

  const filteredMatches = matches.filter(match => 
    match.homeTeam.toLowerCase().includes(searchQuery.toLowerCase()) ||
    match.awayTeam.toLowerCase().includes(searchQuery.toLowerCase()) ||
    match.venue.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="container mx-auto px-4 pt-20">
        <div className="space-y-8">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <h1 className="text-2xl font-bold">Match Schedule</h1>
            <div className="flex flex-col sm:flex-row gap-4 w-full md:w-auto">
              <div className="relative flex-1 sm:flex-initial">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                <Input
                  placeholder="Search matches..."
                  className="pl-10"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <Button onClick={handleCreateMatch} className="w-full sm:w-auto animate-fade-in">
                <Plus className="h-4 w-4 mr-2" />
                Create Match
              </Button>
            </div>
          </div>

          {selectedMatch && (
            <Card className="animate-fade-in">
              <CardHeader>
                <CardTitle>{selectedMatch.homeTeam} vs {selectedMatch.awayTeam}</CardTitle>
                <CardDescription>
                  <div className="flex flex-wrap gap-4">
                    <span className="flex items-center gap-1">
                      <Calendar className="h-4 w-4" /> {selectedMatch.date}
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="h-4 w-4" /> {selectedMatch.time}
                    </span>
                    <span className="flex items-center gap-1">
                      <MapPin className="h-4 w-4" /> {selectedMatch.venue}
                    </span>
                  </div>
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex justify-center items-center gap-8 py-4">
                  <div className="text-center">
                    <h3 className="text-2xl font-bold">{selectedMatch.homeTeam}</h3>
                    {(selectedMatch.status === 'Ongoing' || selectedMatch.status === 'Completed') && (
                      <p className="text-4xl font-bold mt-2">{selectedMatch.homeScore}</p>
                    )}
                  </div>
                  <div className="text-2xl font-bold">vs</div>
                  <div className="text-center">
                    <h3 className="text-2xl font-bold">{selectedMatch.awayTeam}</h3>
                    {(selectedMatch.status === 'Ongoing' || selectedMatch.status === 'Completed') && (
                      <p className="text-4xl font-bold mt-2">{selectedMatch.awayScore}</p>
                    )}
                  </div>
                </div>
              </CardContent>
              <CardFooter className="justify-end">
                <Button variant="outline" onClick={() => setSelectedMatch(null)}>
                  Close
                </Button>
              </CardFooter>
            </Card>
          )}

          <div className="rounded-lg border bg-card">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date & Time</TableHead>
                  <TableHead>Teams</TableHead>
                  <TableHead className="hidden md:table-cell">Venue</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead className="text-right">Score</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredMatches.map((match) => (
                  <TableRow 
                    key={match.id} 
                    className="animate-fade-in cursor-pointer hover:bg-muted/50 transition-colors"
                    onClick={() => handleMatchClick(match)}
                  >
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4 text-muted-foreground" />
                        <span>{match.date}</span>
                        <Clock className="h-4 w-4 ml-2 text-muted-foreground" />
                        <span>{match.time}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="font-medium">
                        {match.homeTeam} vs {match.awayTeam}
                      </div>
                    </TableCell>
                    <TableCell className="hidden md:table-cell">
                      <div className="flex items-center gap-2">
                        <MapPin className="h-4 w-4 text-muted-foreground" />
                        {match.venue}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                        ${match.status === 'Upcoming' ? 'bg-blue-100 text-blue-800' : 
                          match.status === 'Ongoing' ? 'bg-green-100 text-green-800' : 
                          'bg-gray-100 text-gray-800'}`}>
                        {match.status}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="text-sm text-muted-foreground">
                        {match.type}
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      {(match.status === 'Ongoing' || match.status === 'Completed') && (
                        <span className="font-medium">
                          {match.homeScore} - {match.awayScore}
                        </span>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Schedule;
