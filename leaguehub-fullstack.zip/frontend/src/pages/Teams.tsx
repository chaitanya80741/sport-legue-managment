
import { useState } from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Search, Shield, Trophy, Target, ArrowRight } from 'lucide-react';
import { Input } from '@/components/ui/input';
import Navbar from '@/components/Navbar';

type Player = {
  id: string;
  name: string;
  position: string;
  matches: number;
  goals: number;
  assists: number;
};

type Team = {
  id: string;
  name: string;
  logo: string;
  played: number;
  won: number;
  drawn: number;
  lost: number;
  players: Player[];
};

const generateRandomPlayers = (): Player[] => {
  const positions = ['Forward', 'Midfielder', 'Defender', 'Goalkeeper'];
  return Array.from({ length: 5 }, (_, i) => ({
    id: `p${i + 1}`,
    name: `Player ${i + 1}`,
    position: positions[Math.floor(Math.random() * positions.length)],
    matches: Math.floor(Math.random() * 20),
    goals: Math.floor(Math.random() * 15),
    assists: Math.floor(Math.random() * 10),
  }));
};

const generateRandomTeams = (): Team[] => {
  const teamNames = [
    'Red Dragons', 'Blue Knights', 'Green Eagles', 'Yellow Lions',
    'Purple Warriors', 'Orange Tigers', 'Silver Wolves', 'Golden Bears'
  ];
  
  return teamNames.map((name, i) => ({
    id: `t${i + 1}`,
    name,
    logo: `team${i + 1}`,
    played: Math.floor(Math.random() * 20),
    won: Math.floor(Math.random() * 15),
    drawn: Math.floor(Math.random() * 5),
    lost: Math.floor(Math.random() * 5),
    players: generateRandomPlayers(),
  }));
};

const Teams = () => {
  const [teams, setTeams] = useState<Team[]>(generateRandomTeams());
  const [selectedTeam, setSelectedTeam] = useState<Team | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  const filteredTeams = teams.filter(team => 
    team.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="container mx-auto px-4 pt-20">
        <div className="space-y-8 animate-fade-in">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <h1 className="text-2xl font-bold">Teams</h1>
            <div className="relative flex-1 md:max-w-xs">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input
                placeholder="Search teams..."
                className="pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredTeams.map((team) => (
              <Card 
                key={team.id}
                className="hover:shadow-lg transition-shadow duration-300 cursor-pointer"
                onClick={() => setSelectedTeam(team)}
              >
                <CardHeader className="space-y-1">
                  <CardTitle className="flex items-center gap-2">
                    <Shield className="h-5 w-5 text-primary" />
                    {team.name}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-3 gap-4 text-center mb-4">
                    <div>
                      <div className="text-2xl font-bold">{team.played}</div>
                      <div className="text-sm text-muted-foreground">Played</div>
                    </div>
                    <div>
                      <div className="text-2xl font-bold text-green-600">{team.won}</div>
                      <div className="text-sm text-muted-foreground">Won</div>
                    </div>
                    <div>
                      <div className="text-2xl font-bold text-red-600">{team.lost}</div>
                      <div className="text-sm text-muted-foreground">Lost</div>
                    </div>
                  </div>
                  <Button className="w-full" variant="outline">
                    View Squad <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>

          {selectedTeam && (
            <Card className="mt-8 animate-fade-in">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Trophy className="h-5 w-5 text-primary" />
                  {selectedTeam.name} Squad
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Player</TableHead>
                      <TableHead>Position</TableHead>
                      <TableHead className="text-center">Matches</TableHead>
                      <TableHead className="text-center">Goals</TableHead>
                      <TableHead className="text-center">Assists</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {selectedTeam.players.map((player) => (
                      <TableRow key={player.id}>
                        <TableCell className="font-medium">{player.name}</TableCell>
                        <TableCell>{player.position}</TableCell>
                        <TableCell className="text-center">{player.matches}</TableCell>
                        <TableCell className="text-center">{player.goals}</TableCell>
                        <TableCell className="text-center">{player.assists}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          )}
        </div>
      </main>
    </div>
  );
};

export default Teams;

