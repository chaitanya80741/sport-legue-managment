
import { Link } from 'react-router-dom';
import { Trophy, Calendar, Users, BarChart2, Ticket, Bell, ArrowRight } from 'lucide-react';
import Navbar from '@/components/Navbar';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';

const features = [
  {
    icon: Trophy,
    title: 'Live Matches',
    description: 'Real-time scores and match updates'
  },
  {
    icon: Calendar,
    title: 'Match Scheduling',
    description: 'View and book upcoming matches'
  },
  {
    icon: Users,
    title: 'Teams & Players',
    description: 'Detailed stats and performance analysis'
  },
  {
    icon: BarChart2,
    title: 'AI Predictions',
    description: 'Match predictions powered by AI'
  },
  {
    icon: Ticket,
    title: 'Ticket Booking',
    description: 'Easy online ticket reservations'
  },
  {
    icon: Bell,
    title: 'Fan Updates',
    description: 'Latest news and notifications'
  }
];

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      {/* Hero Section */}
      <section className="pt-20 pb-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center animate-fade-in">
            <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold tracking-tight mt-16 mb-4">
              Welcome to <span className="text-primary">LeagueHub</span>
            </h1>
            <p className="text-lg sm:text-xl text-muted-foreground max-w-2xl mx-auto mb-8">
              The ultimate platform for managing sports leagues, teams, and matches with powerful analytics and seamless scheduling.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <Link to="/login">
                <Button size="lg" className="w-full sm:w-auto">
                  Get Started
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
              <Link to="/login">
                <Button variant="outline" size="lg" className="w-full sm:w-auto">
                  View Demo
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-12 px-4 sm:px-6 lg:px-8 bg-secondary/50">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <Link to="/login" key={feature.title}>
                <Card className="h-full transition-all duration-300 hover:scale-105 hover:shadow-lg">
                  <CardContent className="p-6">
                    <feature.icon className="h-12 w-12 text-primary mb-4" />
                    <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                    <p className="text-muted-foreground">{feature.description}</p>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to transform your league management?</h2>
          <p className="text-lg text-muted-foreground mb-8">
            Join thousands of sports organizations already using LeagueHub
          </p>
          <Link to="/login">
            <Button size="lg">
              Start Now
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Index;
