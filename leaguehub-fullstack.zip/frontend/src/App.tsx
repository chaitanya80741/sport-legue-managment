
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { useState } from "react";
import Index from "./pages/Index";
import Dashboard from "./pages/Dashboard";
import Schedule from "./pages/Schedule";
import Teams from "./pages/Teams";
import Tickets from "./pages/Tickets";
import Login from "./pages/Login";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => {
  // Mock authentication state
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  // Mock login function
  const handleLogin = () => {
    setIsAuthenticated(true);
  };

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <div className="min-h-screen bg-background">
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <Routes>
              <Route path="/" element={<Index />} />
              <Route 
                path="/dashboard" 
                element={isAuthenticated ? <Dashboard /> : <Login onLogin={handleLogin} />} 
              />
              <Route 
                path="/schedule" 
                element={isAuthenticated ? <Schedule /> : <Login onLogin={handleLogin} />} 
              />
              <Route 
                path="/teams" 
                element={isAuthenticated ? <Teams /> : <Login onLogin={handleLogin} />} 
              />
              <Route 
                path="/tickets" 
                element={isAuthenticated ? <Tickets /> : <Login onLogin={handleLogin} />} 
              />
              <Route path="/login" element={<Login onLogin={handleLogin} />} />
              <Route path="*" element={<NotFound />} />
            </Routes>
          </BrowserRouter>
        </div>
      </TooltipProvider>
    </QueryClientProvider>
  );
};

export default App;

